<?php
/*
$Id: base.php,v 1.3 2008-10-15 16:20:43 fraynaud1 Exp $
*/

// Base MySQL
$conn [1] = array
    (
        'Openmairie Scrutin mysql',
        'mysql',
        '',
        'root',
        '',
        '',
        'localhost',
        '',
        '',
        'openscrutin',
        'AAAA-MM-JJ'
    );
?>