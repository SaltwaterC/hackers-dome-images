<?php
/**
 * $Id: index.php,v 1.2 2008-07-28 09:09:50 jbastide Exp $
 */
  echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
  echo "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" lang=\"fr\">\n";
  echo "\t<head>\n";
  echo "\t\t<meta http-equiv=\"Content-Type\" content=\"text/html;charset=iso-8859-1\" />\n";
  echo "\t\t<title>Openmairie</title>\n";
  echo "\t</head>\n";
  echo "\t<body>\n";
  echo "\n<center>\n";
  echo "<br>&nbsp;|&nbsp;<a href='javascript:history.go(-1)'>Retour</a>&nbsp;|&nbsp;";
  echo "<br><br><br><img src='encours.png' border='0' alt='aide'>";
  echo "<br><br><br>&nbsp;|&nbsp;<a href=\"http://www.openmairie.org/\" target=\"_blank\" title=\"OpenMairie.org\">OpenMairie.org</a>&nbsp;|&nbsp;</span>\n";
  echo "\n</center>\n";
  echo "\t</body>\n";
  echo "</html>";
?>