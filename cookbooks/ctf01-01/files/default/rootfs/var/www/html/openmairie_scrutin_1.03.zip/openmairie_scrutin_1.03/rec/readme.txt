$Id: readme.txt,v 1.1 2008-01-25 23:38:35 fraynaud1 Exp $

=======================================================================
Toute la documentation d'openMairie sur: 
http://www.openmairie.org
mail: contact@openmairie.org
========================================================================

dans ce repertoire, il est propose des scripts d import au format csv

lancer le script php /rec/import_script.php?obj=agent


obj=agent : script d import agent : import_agent.inc
obj=elu   : script d import elu   : import_elu.inc

voir explication doc/import_script.html

exemple de fichier csv trs/1/utilisateur.csv